package com.example.pokertracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.util.Log

class LoginScreen: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login_screen)

        val noAcc = this.findViewById<TextView>(R.id.questionNoAccount)

        //If the user clicks the link that they have don't have an Account it will send them to
        //the Sign Up screen to register an account
        noAcc.setOnClickListener{
            val goToSignUp=Intent(this,SignUpScreen::class.java)
            startActivity(goToSignUp)
        }
    }
}