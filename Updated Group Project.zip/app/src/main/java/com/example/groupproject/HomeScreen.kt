package com.example.groupproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

//Added for line graph functionality
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries

class HomeScreen : AppCompatActivity() {
    //variable for line graph
    lateinit var lineGraphView: GraphView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        //I added " implementation 'com.jjoe64:graphview:4.2.2' " to add functionality for line graph

        //ToDo:
        //Need to find a way to generate graph image
        //https://www.geeksforgeeks.org/android-line-graph-view-with-kotlin/

        lineGraphView = findViewById(R.id.graphView)

        val testValues=arrayOf(DataPoint(0.0, 1.0),
            DataPoint(1.0, 3.0),
        DataPoint(2.0, 4.0),
        DataPoint(3.0, 9.0),
        DataPoint(4.0, 6.0),
        DataPoint(5.0, 3.0),
        DataPoint(6.0, 6.0),
        DataPoint(7.0, 1.0),
        DataPoint(8.0, 2.0))

        var series: LineGraphSeries<DataPoint> = LineGraphSeries(testValues)

        // on below line adding animation
        lineGraphView.animate()

        // allowing our graph to be scrollable for point graph view
        lineGraphView.viewport.isScrollable = true

        //allowing our graph to be scalable.
        lineGraphView.viewport.isScalable = true

        // setting y to be scalable
        lineGraphView.viewport.setScalableY(true)

        // setting y to be scrollable
        lineGraphView.viewport.setScrollableY(true)

        series.color = R.color.black

        //adding our point to the line graph
        lineGraphView.addSeries(series)


        //ToDo:
        //Need to find a way to update the values for fields

        //Idea: Pass around the list of numbers until a change is successfully made.
        //Clear the list of points and re-add them from the beginning.

        //Idea:just pull data from database everytime we enter this screen

        //ToDo:
        //Update strings.xml and do formatting for the class
    }
}