package com.example.groupproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //Code to start on the Home Screen
        setContentView(R.layout.activity_home_screen)

        /*Code to start on the Login Screen
        setContentView(R.layout.activity_main)

        val noAcc = this.findViewById<TextView>(R.id.questionNoAccount)

        //If the user clicks the link that they have don't have an Account it will send them to
        //the Sign Up screen to register an account
        noAcc.setOnClickListener{
            val goToSignUp=Intent(this,SignUpScreen::class.java)
            startActivity(goToSignUp)
        }
        */
    }
}