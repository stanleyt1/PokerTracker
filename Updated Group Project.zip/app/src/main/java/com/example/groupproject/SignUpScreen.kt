package com.example.groupproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SignUpScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up_screen)

        val yesAcc = this.findViewById<TextView>(R.id.questionYesAccount)

        //If the user clicks the link that they already have an Account it will send them to
        //the Login screen to login
        yesAcc.setOnClickListener{
            val goToLogin= Intent(this,MainActivity::class.java)
            startActivity(goToLogin)
        }
    }
}